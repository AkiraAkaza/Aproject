const fs = require("fs");
const path = require("path");

const coordsLogPath = path.join(__dirname, "..", "coords.txt");

module.exports = {
  name: "kit",
  description: "Free kit like kitbot",
  /**
   * @param {mineflayer.Bot} bot
   * @param {String} user
   * @param {String} msg
   * @param {String[]} args
   */
  async run(bot, user, msg, args) {
    bot.chat("/home kit");

    const onMessage = (message) => {
      if (message.includes("Teleporting to home kit")) {
        setTimeout(() => {
          bot.chat(`/tpa ${user}`);
        }, 1000);
      }

      if (message.includes("Teleporting...")) {
        const entity = bot.nearestEntity(e => e.type !== "player");
        if (entity) {
          bot.chat("/kill");

          bot.once("death", () => {
            const pos = bot.entity.position;
            const dimension = bot.game.dimension;
            const log = `${user} - ${dimension} (${Math.floor(pos.x)}, ${Math.floor(pos.z)})\n`;

            fs.mkdir(path.dirname(coordsLogPath), { recursive: true }, (err) => {
              if (err) {
                console.error("Failed to create log directory:", err);
                return;
              }

              fs.appendFile(coordsLogPath, log, (err) => {
                if (err) console.error("Failed to log coordinates:", err);
                else console.log(`Logged coordinates for ${user}.`);
              });
            });
          });

          bot.removeListener("messagestr", onMessage);
        }
      }
    };

    bot.on("messagestr", onMessage);
  },
};
