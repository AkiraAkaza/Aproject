const mineflayer = require('mineflayer')

module.exports = {
    name: 'seed',
    description: 'Seed 8b8t server',
    /**
     * 
     * @param {mineflayer.Bot} bot 
     * @param {String} user 
     * @param {String} msg 
     * @param {String[]} args 
     */
    async run(bot, user, msg, args) {
        bot.chat("> Seed server is: -762204300219715536")
    }
}