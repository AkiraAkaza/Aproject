const fs = require('fs');
const path = require('path');
const mineflayer = require('mineflayer');

module.exports = {
    name: 'help',
    description: 'Xem toàn bộ lệnh của bot',
    /**
     * 
     * @param {mineflayer.Bot} bot 
     * @param {String} user 
     * @param {String} msg 
     * @param {String[]} args 
     */
    async run(bot, user, msg, args) {
        const commandsPath = path.join(__dirname);

        if (!args[0]) {
            const files = fs.readdirSync(commandsPath)
                .filter(file => file.endsWith('.js'))
                .map(file => path.parse(file).name);

            bot.chat('Hiện tại có các lệnh: ' + files.join(', '));
        } else {
            const cmd = bot.commands.find(c => c.name === args[0]);
            if (!cmd) return bot.whisper(user, `Không có lệnh ${args[0]}`);
            bot.whisper(user, `Lệnh: ${cmd.name} - Mô tả: ${cmd.description || 'Không có mô tả.'}`);
        }
    }
};
