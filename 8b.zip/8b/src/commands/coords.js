const mineflayer = require('mineflayer');
const config = require('../config.json');

module.exports = {
  name: 'coords',
  description: '',
  /**
   * @param {mineflayer.Bot} bot 
   * @param {String} user 
   * @param {String} msg 
   * @param {String[]} args 
   */
  async run(bot, user, msg, args) {
    const administrator = config.utils['auto-auth'].administrator;

    if (!administrator.includes(user.toLowerCase())) {
      bot.whisper('Bạn không có quyền sử dụng lệnh này');
      return;
    }

    bot.whisper(user, `${Math.floor(pos.x)}, ${Math.floor(pos.z)})`);
  }
};
