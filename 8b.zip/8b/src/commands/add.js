const fs = require("fs");
const path = require("path");

const configPath = path.join(__dirname, "..", "config.json");
let config = require(configPath); // Tải config

module.exports = {
  name: "add",
  description: "Add a user to the kit whitelist",
  /**
   * @param {mineflayer.Bot} bot
   * @param {String} user - Người gọi lệnh
   * @param {String} msg  - Tin nhắn đầy đủ (!add ...)
   * @param {String[]} args - Mảng chứa các phần sau !add
   */
  async run(bot, user, msg, args) {
    const adminList = config.utils["auto-auth"].administrator.map(u => u.toLowerCase());
    const username = user.toLowerCase();

    if (!adminList.includes(username)) {
      bot.chat(`@${user} You do not have permission to use this command.`);
      return;
    }

    const target = args[0]?.toLowerCase();

    if (!target) {
      bot.chat(`@${user} Usage: !add <username>`);
      return;
    }

    const whitelist = config.utils["kit-whitelist"].map(u => u.toLowerCase());

    if (whitelist.includes(target)) {
      bot.chat(`@${user} ${target} is already whitelisted.`);
      return;
    }

    config.utils["kit-whitelist"].push(target);

    try {
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
      bot.chat(`✅ ${target} has been added to the kit whitelist.`);
    } catch (err) {
      console.error("Failed to write config.json:", err);
      bot.chat(`@${user} Failed to update config file.`);
    }
  },
};
