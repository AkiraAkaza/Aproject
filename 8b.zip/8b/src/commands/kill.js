const mineflayer = require('mineflayer');
const config = require('../config.json');

module.exports = {
  name: 'kill',
  description: 'Kill the bot',
  /**
   * @param {mineflayer.Bot} bot 
   * @param {String} user 
   * @param {String} msg 
   * @param {String[]} args 
   */
  async run(bot, user, msg, args) {
    const administrator = config.utils['auto-auth'].administrator;

    if (!administrator.includes(user.toLowerCase())) {
      bot.whisper(user, 'Bạn không có quyền sử dụng lệnh này');
      return;
    }

    bot.chat('/kill');
  }
};
