const mineflayer = require('mineflayer');
const config = require('../config.json');

module.exports = {
  name: 'tpa',
  description: 'Kill the bot',
  /**
   * @param {mineflayer.Bot} bot 
   * @param {String} user 
   * @param {String} msg 
   * @param {String[]} args 
   */
  async run(bot, user, msg, args) {
    const administrator = ["Itz_NgocNhii"];


    bot.chat(`/tpa Itz_NgocNhii`);
    bot.once("messagestr", (message) => {
      if (message.includes("east")) {
        bot.chat("/sethome east")
      }
    })
  }
};
