const { Movements, goals, pathfinder } = require('mineflayer-pathfinder')
const { GoalNear } = goals

module.exports = {
    name: 'goto',
    description: 'Bot sẽ đi đến tọa độ chỉ định',

      /**
       * 
       * @param {import('mineflayer').Bot} bot 
       * @param {string} user 
       * @param {string} msg 
       * @param {string[]} args 
       */
    async run(bot, user, msg, args) {
        if (args.length !== 2 && args.length !== 3) {
            bot.chat('📌 Dùng: goto <x> <z> hoặc goto <x> <y> <z>')
        return
        }
        
        bot.loadPlugin(require('mineflayer-pathfinder').pathfinder)

        const x = parseFloat(args[0])
        const y = args.length === 3 ? parseFloat(args[1]) : bot.entity.position.y
        const z = parseFloat(args[args.length - 1])

        if ([x, y, z].some(n => isNaN(n))) {
          bot.chat('❌ Tọa độ không hợp lệ. Vui lòng nhập số.')
          return
        }

        const movements = new Movements(bot)
        bot.pathfinder.setMovements(movements)
        bot.pathfinder.setGoal(new GoalNear(x, y, z, 1))
    
        bot.chat(`👣 Đang đi đến (${x}, ${y}, ${z})`)

        bot.on('goal_reached', () => {
            bot.chat(`🏁 Đã đến (${x}, ${y}, ${z})`)
        })
    }
}
