require('dotenv').config();
const mineflayer = require('mineflayer');
const tpsPlugin = require('mineflayer-tps')(mineflayer);
const pathfinder = require('mineflayer-pathfinder').pathfinder;

const fs = require('fs');
const path = require('path');
const config = require('./config.json');
const prefix = config.utils.dsc.prefix;

function createBot() {
   const bot = mineflayer.createBot({
      username: config['bot-account']['username'],
      password: config['bot-account']['password'],
      auth: config['bot-account']['type'],
      host: config.server.ip,
      port: config.server.port,
      version: config.server.version,
   });

   bot.loadPlugin(tpsPlugin);
   bot.loadPlugin(pathfinder)
   bot.commands = [];

    //--------------------Mineflayer_Commands--------------------//

   const commandsPath = path.join(__dirname, 'commands');

   fs.readdirSync(commandsPath)
     .filter(file => file.endsWith('.js'))
     .forEach(file => {
        const pull = require(path.join(commandsPath, file));
        if (pull.name) {
           bot.commands.push(pull);
        }
   });

   if (config.utils['dsc'].enabled) {
      discordBridge(bot);
   }

   bot.on('chat', async (user, msg) => {
      if (!msg.startsWith(prefix)) return;
      const args = msg.slice(prefix.length).trim().split(/ +/g);
      const cmd = args.shift().toLowerCase();
      const command = bot.commands.find(c => c.name == cmd);
      if (command) {
         if (command.admin && user.trim() !== config.admin) return;
         command.run(bot, user, msg, args);
      }
   });

    //--------------------8b8t.me_Login--------------------//
   
   bot.once('login', () => {
      console.log("Bot joined to the server");

      if (config.utils['auto-auth'].enabled) {
         console.log('Started auto-auth module');

         setTimeout(() => {
            bot.on("messagestr", (message) => {
               if (message.includes("/register")) {
                  bot.chat(`/register ${config.utils['auto-auth'].password} ${config.utils['auto-auth'].password}`);
               } else if (message.includes("[8b8t] >> Use the command /login <password>.")) {
                  bot.chat(`/login ${config.utils['auto-auth'].password}`);
                  setTimeout(() => {
                     bot.chat(`/8b8t`)
                  }, 500)
               } else if (message.includes(`Welcome ${config['bot-account']['username']} to the server!`)) {
                  bot.chat("/8b8t");
               } else if (message.includes("You are already registered")) {
                  console.log(`❌ Bạn đã đăng ký`);
               } else if (message.includes("You are already logged in")) {
                  console.log(`❌ Bạn đã đăng nhập`);
               } else if (message.includes("Your login session has been continued.")) {
                  bot.chat(`/8b8t`)
               } else if (message.includes("You have successfully logged.")) {
                  bot.chat(`/8b8t`)
               } else if (message.includes("[8b8t] Unknown command do /help")) {
                  bot.chat(`/8b8t`)
               }
            })
         }, 100);

         console.log(`Authentication commands executed`);
      }

       //--------------------Chat_messages--------------------//
      
      if (config.utils['chat-messages'].enabled) {
         console.log('Started chat-messages module');

         let messages = config.utils['chat-messages']['messages'];

         if (config.utils['chat-messages'].repeat) {
            let delay = config.utils['chat-messages']['repeat-delay'];
            let i = 0;

            setInterval(() => {
               bot.chat(`${messages[i]} |[${randomSrc()}]`);

               if (i + 1 === messages.length) {
                  i = 0;
               } else i++;
            }, delay * 1000);
         } else {
            messages.forEach((msg) => {
               bot.chat(msg + ` |[${randomSrc()}]`);
            });
         }
      }

      if (config.utils['anti-afk'].enabled) {
         if (config.utils['anti-afk'].sneak) {
            bot.setControlState('sneak', true);
         }

         if (config.utils['anti-afk'].jump) {
            bot.setControlState('jump', true);
         }

         if (config.utils['anti-afk']['hit'].enabled) {
            let delay = config.utils['anti-afk']['hit']['delay'];
            let attackMobs = config.utils['anti-afk']['hit']['attack-mobs']
            const item = bot.inventory.findInventoryItem(`${config.utils['anti-afk'].hit.sword}_sword`);
            if (!item) return console.log(`⚠️ Không tìm thấy kiếm ${config.utils['anti-afk'].hit.sword}_sword`);
            
            bot.equip(item, "hand");
            setInterval(() => {
               if(attackMobs) {
                     let entity = bot.nearestEntity(e => e.type !== 'object' && e.type !== 'player'
                         && e.type !== 'global' && e.type !== 'orb' && e.type !== 'other');

                     if(entity) {
                        bot.attack(entity);
                        return
                     }
               }

               bot.swingArm("right", true);
            }, delay);
         }

         if (config.utils['anti-afk'].rotate) {
            setInterval(() => {
               bot.look(bot.entity.yaw + 1, bot.entity.pitch, true);
            }, 100);
         }
      }
   });

   bot.on('message', (message) => {
      if (config.utils['chat-log']) {
         console.log(message.toAnsi())
      }
   })

   bot.on('error', (err) =>
      console.log(`${err.message}`)
   );
}

function discordBridge(bot) {
   const ms = require('ms');
   const config = require('./config.json');
   const livechat = config.utils.dsc['channel-id'];
   const reconnect = config.utils["auto-reconnect-delay"];
   const { Client,  Events, GatewayIntentBits, EmbedBuilder } = require('discord.js');
   
   const client = new Client({
      intents: [
         GatewayIntentBits.Guilds,
         GatewayIntentBits.GuildMessages,
         GatewayIntentBits.MessageContent,
         GatewayIntentBits.GuildMessageReactions,
      ]
   });

    //--------------------Login_Discord--------------------//
   
   client.once('ready', () => {
      const channel = client.channels.cache.get(livechat);
      if (!channel) {
         console.log(`⚠️ Không tìm thấy channel (${livechat})`);
         process.exit(1);
      } else {
         console.log(`Discord bot đã đăng nhập: ${client.user.tag}`);
      }
   });

   client.login(process.env.DISCORD_TOKEN);

    //--------------------Discord_Bridge--------------------//

   bot.once('login', () => {
      bot.once('spawn', () => {
         const spawn = new EmbedBuilder()
            .setTitle(`✅ ${bot.username} đã vào server ${config.server.ip}`)
            .setColor(0x008000)
            .setFooter({ text: config.server.ip })
            .setTimestamp();

         const channel = client.channels.cache.get(livechat);
         if (channel) {
            channel.send({ embeds: [spawn] });
         } else {
            console.error(`❌ Không tìm thấy channel ID: ${livechat}`);
         }
      });
   });

   bot.on('death', () => {
      const death = new EmbedBuilder()
        .setTitle(`❌ Bot has been died and was respawned at ${bot.entity.position}`)
        .setColor(0xff0000)
        .setFooter({ text: config.server.ip })
        .setTimestamp();

      const channel = client.channels.cache.get(livechat);
      if (channel) {
        channel.send({ embeds: [death] });
      } else {
        console.error(`❌ Không tìm thấy channel ID: ${livechat}`);
      }
   });

   bot.on('end', (reason) => {
      const end = new EmbedBuilder()
         .setTitle(`❌ ${bot.username} bị mất kết nối`)
         .setDescription(`Lý do: \`${reason}\`\nTự động kết nối lại sau ${reconnect} giây...`)
         .setColor(0xff0000)
         .setFooter({ text: config.server.ip })
         .setTimestamp();

      const channel = client.channels.cache.get(livechat);
      if (channel) {
         channel.send({ embeds: [end] });

         setTimeout(() => {
            const relog = new EmbedBuilder()
               .setTitle(`🔄 Đang kết nối lại với server...`)
               .setColor(0xffff00)
               .setFooter({ text: config.server.ip })
               .setTimestamp();
   
            channel.send({ embeds: [relog] });
            createBot();
         }, ms(`${reconnect}s`));
      }
   });

   bot.on('chat', (username, message) => {
      const embed = new EmbedBuilder()
         .setTitle(`💬 ${username}`)
         .setDescription(`\`${message}\``)
         .setColor(0xffffff)
         .setFooter({ text: config.server.ip })
         .setTimestamp();

      const channel = client.channels.cache.get(livechat);
      if (channel) {
         channel.send({ embeds: [embed] })
      }
   })
}

//--------------------Random_Alphabet--------------------//

function randomSrc() {
    const alphabet = 'abcdefghijklmnopqrstuvwxyz';
    let rdChars = '';
    for (let i = 0; i < 2; i++) {
        rdChars += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    }
    return rdChars;
}

createBot();